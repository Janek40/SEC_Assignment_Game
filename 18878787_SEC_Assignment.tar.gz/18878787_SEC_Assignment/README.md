# SEC_Assignment_Game
SEC assignment

Compiling: 
1. Navigate to Project/
2. gradle build
 
Preparation:
1. Manually move your Question types (.jar files) to plugins/QuestionTypes/
2. Manually move your Quizzes (.jar files) to plugins/Quizzes/
OR
1. run the script: quizRun.sh
 
Running: 
./quizRun.sh 
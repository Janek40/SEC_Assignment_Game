/***************************************************************************
* Author: Janek Joyce
* Last Updated: 15/09/2018
* Purpose: Runs the GUI
*          This code is intended for the 2018 semester 1 SEC assignment
***************************************************************************/

import java.util.List;
import java.util.ArrayList;
import java.io.IOException;

import javafx.application.Application;

public class Mainf
{
    public static void main(String[] args)
    {
	Application.launch(GUI.class, args);
    }
}
